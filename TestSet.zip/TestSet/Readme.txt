This zip file include the test sets for the following working paper:
Cheng Lu, Zhibin Deng, Shu-Cherng Fang and Wenxun Xing: A Branch-and-Bound Algorithm for Max-Cut Problem by Using Tree Decomposition, 2021.

If you have any question, please contact Prof. Zhibin Deng at <zhibindeng@ucas.edu.cn>

